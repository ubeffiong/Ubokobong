﻿namespace IHVNMedix.Models
{
    public class HealthIssueInfo
    {
        public int IssueID { get; set; }
        public string Name { get; set; }
    }
}
